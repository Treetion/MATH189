



library(quantmod)
library(lattice)
library(timeSeries)
library(rugarch)

n1  = length(SPreturn)
year_SP = 1981 + (1:n1)* (1991.25-1981)/n1
d1 = seq(as.Date("1981-01-01"), as.Date("1991-04-01"), by=1)
date_SP = d1[seq(1,length(d1),by=length(d1)/n1)]

n2 = length(diffdm)
year_dm = 1980 + (1:n2)* (1987.5-1980)/n2
d2 = seq(as.Date("1980-01-01"), as.Date("1987-07-01"), by=1)
date_dm = d2[seq(1,length(d2),by=length(d2)/n2)]

n3 = length(difflogrf)
year_rf = 1960 + (1:n3) * (2003 - 1960)/n3
d3 = seq(as.Date("1960-01-01"), as.Date("2003-01-01"), by=1)
date_rf = d3[seq(1,length(d3),by=length(d3)/n3)]

n4 = length(infl)
year_infl = 1950+1/12 + (1:n4) * (1991-1950-1/12)/n4
d4 = seq(as.Date("1950-02-01"), as.Date("1991-01-01"), by=1)
date_infl = d4[seq(1,length(d4),by=length(d4)/n4)]
# Getting the SP500 values from Yahoo Finance database
sp500 <- new.env()
getSymbols("^GSPC", from="1975-01-01")
spReturns = diff(log(Cl(GSPC)))


#remove NA values and replace with 0
spReturns[as.character(head(index(Cl(GSPC)),1))] = 0

#view of the data downloaded
head(GSPC$GSPC.Volume)
GSPC["1970-03"]


# Forecasting
#choosing the windowlength
windowLen = 900

#figuring forelength
foreLength = length(spReturns) - windowLen

forecasts <- vector(mode="character", length=foreLength)


for (d in 0:foreLength) {
 
  spReturnsOffset = spReturns[(1+d):(windowLen+d)]
  
  # Fitting the ARIMA model
  final.aic <- Inf
  
  final.order <- c(0,0,0)

#checking 24 ARIMA models
  
  for (p in 0:5) for (q in 0:5) {
      
    if ( p == 0 && q == 0) {
      next
    }
    
#handle exceptions when p and q value is not fit
      
    arimaFit = tryCatch( arima(spReturnsOffset, order=c(p, 0, q)),
                         error=function( err ) FALSE,
                         warning=function( err ) FALSE )


#picking the best AIC value from the different ARIMA models fitted
    
    if( !is.logical( arimaFit ) ) {
      current.aic <- AIC(arimaFit)
      if (current.aic < final.aic) {
        final.aic <- current.aic
        final.order <- c(p, 0, q)
        final.arima <- arima(spReturnsOffset, order=final.order)
      }
    } else {
      next
    }
  }
  
  # Fitting the GARCH model
  spec = ugarchspec(
    variance.model=list(garchOrder=c(1,1)),
    mean.model=list(armaOrder=c(final.order[1], final.order[3]), include.mean=T),
    distribution.model="sged"
  )
  #handle exceptions
  
  fit = tryCatch(
    ugarchfit(
      spec, spReturnsOffset, solver = 'hybrid'
    ), error=function(e) e, warning=function(w) w
  )
  
  # If does not converge, chose +1
  if(is(fit, "warning")) {
    forecasts[d+1] = paste(index(spReturnsOffset[windowLength]), 1, sep=",")
    print(paste(index(spReturnsOffset[windowLength]), 1, sep=","))
    
  } else {
    fore = ugarchforecast(fit, n.ahead=1)
    ind = fore@forecast$seriesFor
    forecasts[d+1] = paste(colnames(ind), ifelse(ind[1] < 0, -1, 1), sep=",")
   
  }
}




# Output "forecasts.csv"

write.csv(forecasts, file="forecasts.csv", row.names=FALSE)

am = arch_model(eps)
res = am.fit(update_freq=5)
print(res.summary())


np.random.seed(3)

a0 = 0.2
a1 = 0.5
b1 = 0.3

n = 10000
w = np.random.normal(size=n)
eps = np.zeros_like(w)
sigsq = np.zeros_like(w)




# Fixed CSV file
spArimaGarch = as.xts( 
  read.zoo(
    file="forecasts_new.csv", format="%Y-%m-%d", header=F, sep=","
  )
)

armaSearch = function( # default parameter
    xx, 
    minOrder=c(0,0), 
    maxOrder=c(5,5),
    trace=FALSE )
{
    bestAic = 1e9 # initial aic
    len = NROW( xx )
    # search through all p, q order combination
    for( p in minOrder[1]:maxOrder[1] ) for( q in minOrder[2]:maxOrder[2] ) 
    {
        if( p == 0 && q == 0 )
        {   
            next
        }   

        
returns = pd.DataFrame(index = signal.index, 
                       columns=['Buy and Hold', 'Strategy'])
returns['Buy and Hold'] = lrets[-foreLength:]
returns['Strategy'] = signal['SPX']*returns['Buy and Hold']
eqCurves = pd.DataFrame(index = signal.index, 
                        columns=['Buy and Hold', 'Strategy'])
eqCurves['Buy and Hold']=returns['Buy and Hold'].cumsum()+1
eqCurves['Strategy'] = returns['Strategy'].cumsum()+1
eqCurves['Strategy'].plot(figsize=(10,8))
eqCurves['Buy and Hold'].plot()
plt.legend()
plt.show()

import auquanToolbox.dataloader as dl
start = ‘2010–01–01’
end = ‘2017–01–01’

symbols = [‘SPX’]
data = dl.load_data_nologs(‘nasdaq’, symbols , start, end)[‘ADJ CLOSE’]
# log returns
lrets = np.log(data/data.shift(1)).dropna()


# ARIMA+GARCH returns
spIntersect = merge( spArimaGarch[,1], spReturns, all=F )

spArimaGarchReturns = spIntersect[,1] * spIntersect[,2]

# backtests of ARIMA+GARCH vs B&H strategy
spArimaGarchCurve = log( cumprod( 1 + spArimaGarchReturns ) )
spBuyHoldCurve = log( cumprod( 1 + spIntersect[,2] ) )


spCombinedCurve = merge( spArimaGarchCurve, spBuyHoldCurve, all=F )

# Plot
xyplot( 
  spCombinedCurve,
  superpose=T,
  col=c("green", "black"),
  lwd=2,
  key=list( 
    text=list(
      c("ARIMA+GARCH", "B&H")
    ),
    lines=list(
      lwd=2, col=c("green", "black")
    )
  )
)

  
